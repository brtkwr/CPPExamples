#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
using namespace std;
#include <stdio.h>
#include <string.h>
#include "Graphics.h"
#define LastPrevious 1000
float x[3][LastPrevious+1],xDot[3],xDoubleDot[3],xToPlot[LastPrevious+1],yToPlot[LastPrevious+1],rv[2],
TWO_PI,a,theta,deltat,beta,ro,sigma;
int main(void)
{
	TWO_PI=8.0*atan(1.0);
	theta=0.0;
	deltat=0.0005;
	a=15.0;
	
	for(int Previous=0;Previous<=LastPrevious;Previous++)
	{
		x[0][Previous]=-10.0*a;
		x[1][Previous]=+10.0*a;
		x[2][Previous]=+25.0*a;
	}
	beta=8.0/3.0;
	ro=28.0;
	sigma=10.0;
	ChrisGraphics(0.0,0.0,0.0);
	return 0;
}
static void Draw(void)
{   
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLineWidth(1.0);
	theta+=0.002;
	if(theta>TWO_PI)theta-=TWO_PI;
	float costheta=cos(theta);
	float sintheta=sin(theta);
	for(int Cycle=0;Cycle<=9;Cycle++)
	{
		xDot[0]=sigma*(x[1][0]-x[0][0]);
		xDot[1]=(ro-x[2][0]/a)*x[0][0]-x[1][0];
		xDot[2]=x[0][0]*x[1][0]/a-beta*x[2][0];
		xDoubleDot[0]=sigma*(xDot[1]-xDot[0]);
		xDoubleDot[1]=(-xDot[2]/a)*x[0][0]+(ro-x[2][0]/a)*xDot[0]-xDot[1];
		xDoubleDot[2]=xDot[0]*x[1][0]/a+x[0][0]*xDot[1]/a-beta*xDot[2];
		for(int i=0;i<=2;i++)x[i][0]+=xDot[i]*deltat+xDoubleDot[i]*deltat*deltat/2.0;
	}
	for(int Previous=LastPrevious;Previous>=1;Previous--)
	{
		for(int i=0;i<=2;i++)x[i][Previous]=x[i][Previous-1];
	}
	for(int Previous=0;Previous<=LastPrevious;Previous++)
	{
		xToPlot[Previous]=x[0][Previous]*costheta+x[1][Previous]*sintheta;
		yToPlot[Previous]=-x[2][Previous]+25.0*a;
	}
	glBegin(GL_LINE_STRIP);
	for(int Previous=0;Previous<=LastPrevious-1;Previous++)
	{
		float factor=(1.0-float(Previous)/float(LastPrevious));
		float rv[2];
		glColor4f(1.0,1.0,1.0,1.0*factor);
		rv[0]=xToPlot[Previous];
		rv[1]=-yToPlot[Previous];
		glVertex2fv(rv);
	}
	glEnd();
	glPointSize(10);
	glColor4f(0.0,0.0,1.0,1.0);
	glBegin(GL_POINTS);
	rv[0]=xToPlot[0];
	rv[1]=-yToPlot[0];
	glVertex2fv(rv);
	glEnd();
	glutSwapBuffers();
}
