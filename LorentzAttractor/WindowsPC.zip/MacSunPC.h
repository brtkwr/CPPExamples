//#include <GLUT/glut.h>  // For Macintosh
#include <GL/glut.h>    // For PC or Sun
#define   Macintosh 0   //1 for Macintosh any other number for PC or Sun
