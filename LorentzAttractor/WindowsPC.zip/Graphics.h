#include "MacSunPC.h"

#define HalfWidth     640
#define HalfHeight    375

void ChrisGraphics(float BackGroundRed,float BackGroundGreen,float BackGroundBlue);
static void Draw(void);
static void Key(unsigned char key, int x, int y);

GLUquadricObj *quadObj;

int argc;

char **argv;

void ChrisGraphics(float BackGroundRed,float BackGroundGreen,float BackGroundBlue)
{
	glutInitWindowSize(2*HalfWidth, 2*HalfHeight);
	if(Macintosh==1)    glutInit(&argc, argv);               // Remove this line for PC or Sun
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Lorenz Attractor");
	glClearColor(BackGroundRed,BackGroundGreen,BackGroundBlue,0);
	glViewport(0, 0, 2*HalfWidth, 2*HalfHeight);
	glOrtho(-HalfWidth,HalfWidth,-HalfHeight,HalfHeight,-HalfHeight,HalfHeight);
	glClear(GL_COLOR_BUFFER_BIT);
	glutKeyboardFunc(Key);
	glutIdleFunc(Draw);
	glutDisplayFunc(Draw);
	glEnable(GL_BLEND);
	glEnable(GL_SMOOTH);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glutMainLoop();
}
static void Key(unsigned char key, int x, int y)
{
switch (key)
{
case 'q':gluDeleteQuadric(quadObj);exit(0);
case 'Q':gluDeleteQuadric(quadObj);exit(0);
case '\033':gluDeleteQuadric(quadObj);exit(0);
}
}
