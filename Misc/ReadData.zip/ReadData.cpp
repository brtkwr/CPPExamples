#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
using namespace std;

ifstream Maud("OriginalData.txt");
ofstream Chris("WrittenData.txt");

int main(void)
{
	int LastNumber;
	Maud>>LastNumber;
	Chris<<LastNumber<<"\n";
	cout<<"Last number is "<<LastNumber<<"\n";
	for(int Number=0;Number<=LastNumber;Number++)
	{
		double ThisNumber;
		Maud>>ThisNumber;
		Chris<<ThisNumber<<"\n";
		cout<<Number<<"\t"<<ThisNumber<<"\n";
	}
	cout<<"Press 'Return' to close\n";char Pause;Pause=getchar();
}
