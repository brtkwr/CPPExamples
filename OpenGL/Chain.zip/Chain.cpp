#include <iostream>
#include <fstream>
#include <cmath>
#include <stdlib.h>
#include <time.h>
using namespace std;
#if defined(__APPLE__)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#define   LastNode   30
void Calculation(void);
void SetUpGraphics(double BackGroundRed,double BackGroundBlue,double BackGroundGreen);
static void Draw(void);
static void Key(unsigned char key, int x, int y);
GLUquadricObj *quadObj;
int HalfDimension[2],points,lines;
double x[2][LastNode+1],Force[2][LastNode+1],Velocity[2][LastNode+1],deltax[2],
L[LastNode],LSq[LastNode],EA[LastNode],PI,
g,deltat,m,mg,ActualLSq,ToverL,mu,OneMinusmu,RedPeak,peak;

int main(int argc, char* argv[]){
	PI=4.0*atan(1.0);
	cout<<"'q' or 'ESC' stops the program.\n";
	m=1.0;g=0.00001;mg=m*g;
	for(int Node=0;Node<=LastNode-1;Node++){
		L[Node]=600.0*double((Node+1))/(0.5*double((LastNode-1)*LastNode));
		LSq[Node]=L[Node]*L[Node];
		EA[Node]=(Node+1)/(1.0*LastNode);}
	deltat=0.5*sqrt((m*L[0])/(EA[0]/L[0]));
	RedPeak=0.1;points=1;lines=1;
	for(int Node=LastNode;Node>=0;Node--){
		double TotalLength;
		if(Node==LastNode){TotalLength=0.0;x[0][Node]=0.0;x[1][Node]=300.0;}
		else {TotalLength+=L[Node];
			x[0][Node]=x[0][Node+1]+L[Node]*sin(PI*TotalLength/1000.0);
			x[1][Node]=x[1][Node+1]-L[Node]*cos(PI*TotalLength/1000.0);}
		Velocity[0][Node]=0.0;Velocity[1][Node]=0.0;}
	glutInit(&argc,argv);SetUpGraphics(1.0,1.0,1.0);
	return 0;}

static void Draw(void){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	Calculation();
	glutSwapBuffers();}

void Calculation(void){
	for(int Node=0;Node<=LastNode;Node++){
		Force[0][Node]=0.0;Force[1][Node]=-mg*L[Node];}
	for(int Node=0;Node<=LastNode-1;Node++){
		for(int i=0;i<=1;i++)deltax[i]=x[i][Node+1]-x[i][Node];
		ActualLSq=deltax[0]*deltax[0]+deltax[1]*deltax[1];
		ToverL=EA[Node]*(ActualLSq-LSq[Node])/(2.0*L[Node]*ActualLSq);
		for(int i=0;i<=1;i++){
			Force[i][Node  ]+=ToverL*deltax[i];
			Force[i][Node+1]-=ToverL*deltax[i];}
		for(int i=0;i<=1;i++){
			Velocity[i][Node]+=deltat*Force[i][Node]/(m*L[Node]);
			x[i][Node]+=deltat*Velocity[i][Node];}}
	glPointSize(5.0);glColor4f(1.0,0.0,0.0,1.0);glBegin(GL_POINTS);
	glVertex2d(x[0][LastNode],x[1][LastNode]);glEnd();
	if(points==1){
		glPointSize(2.0);glColor4f(1.0,0.0,0.0,1.0);glBegin(GL_POINTS);
		for(int Node=0;Node<=LastNode-1;Node++)
			glVertex2d(x[0][Node],x[1][Node]);
		glEnd();}
	glLineWidth(2.0);
	glColor4f(0.5,0.5,0.5,0.8);
	glBegin(GL_LINE_STRIP);
	for(int Node=0;Node<=LastNode;Node++)
		glVertex2d(x[0][Node],x[1][Node]);
	glEnd();}

void SetUpGraphics(double BackGroundRed,double BackGroundGreen,double BackGroundBlue){
	int screenWidth = glutGet(GLUT_SCREEN_WIDTH);
	int screenHeight = glutGet(GLUT_SCREEN_HEIGHT);
	cout<<"Your screen resolution is "<<screenWidth<<" x "<<screenHeight<<"\n";
	HalfDimension[0]=int(double(screenWidth)/2.0)-5;
	HalfDimension[1]=int(double(screenHeight)/2.0)-25;
	glutInitWindowSize(2*HalfDimension[0],2*HalfDimension[1]);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Chain");
	glClearColor(BackGroundRed,BackGroundGreen,BackGroundBlue,0);
	glViewport(0, 0, 2*HalfDimension[0], 2*HalfDimension[1]);
	gluOrtho2D(-HalfDimension[0],HalfDimension[0],-HalfDimension[1],HalfDimension[1]);
	glClear(GL_COLOR_BUFFER_BIT);
	glutKeyboardFunc(Key);
	glutIdleFunc(Draw);
	glutDisplayFunc(Draw);
	glEnable(GL_BLEND);
	glEnable(GL_SMOOTH);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_TEXTURE);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	double Zoom=HalfDimension[1]/400.0;
	glScalef(Zoom,Zoom,Zoom);
	glutMainLoop();}

static void Key(unsigned char key, int x, int y){
	switch (key){
		case 'p':if(points==0)points=1;else points=0;break;
		case 'l':if(lines==0)lines=1;else lines=0;break;
		case 'q':gluDeleteQuadric(quadObj);exit(0);
		case '\033':gluDeleteQuadric(quadObj);exit(0);}}
