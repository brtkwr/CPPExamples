//Written by Chris J K Williams, University of Bath, UK

#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
using namespace std;

#include "Graphics.h"

void Calculation(void);
void Axial(int i,int inext,int j,int jnext);
void Bending(int i,int inext,int inextnext,int j,int jnext,int jnextnext);

#define   mMax 256
#define   nMax 256

int    NodeType[mMax + 1][nMax + 1],m,n;
float x[mMax + 1][nMax + 1][3],force[mMax + 1][nMax + 1][3],velocity[mMax + 1][nMax + 1][3],
Stiffness[mMax + 1][nMax + 1],
deltaA[3],deltaB[3],deltax[3],Radius[3],SphereCentre[3],PointPosition[2],
EAOverTwoSlackCubed,EAOverSlack,
slackSq,
eta,weightpernode,carryover,factor,
SphereRadius,SphereRadiusSq,Rad,RadSq,dot,eighteta,myfloor,root2,
upper,lower,shift,xscale,yscale,scale;

char *MyText;

int main(int argc, char *  argv[])
{
	cout<<"The program will now run forever until 'q' or ESCAPE is pressed on the keyboard\n";
	cout<<"Left mouse button for pan\n";
	cout<<"Right mouse button (or CONTROL left button) for rotate\n";
	cout<<"Move spot to zoom\n";
	cout<<"Do you want fine  =  1, medium  =  2, coarse  =  4 or super coarse  =  8?\n";
	int coarseness;
	for(;;)
	{
		cin>>coarseness;if(coarseness == 1||coarseness == 2||coarseness == 4||coarseness == 8)break;
		cout<<"1, 2, 4 or 8 please.\n";
	}
	m = mMax/coarseness;
	n = nMax/coarseness;
	int mcentre = int(0.45 * m);
	int ncentre = int(0.48 * n);
	float slack = 500.0/(1.0 * m);
	slackSq = slack * slack;
	EAOverTwoSlackCubed = 1.0;
	EAOverSlack = EAOverTwoSlackCubed * 2.0 * slack * slack;
	eta = 5.0 * EAOverSlack;
	weightpernode = 0.01 * EAOverSlack * slack;
	factor = 1.0;
	carryover = 0.999;
	eighteta = 8.0 * eta;
	SphereRadius = 50.0;SphereCentre[0] = 0.0;SphereCentre[1] = 0.0;SphereCentre[2] = 100.0;
	SphereRadiusSq = SphereRadius * SphereRadius;
	myfloor =  - 300.0;
	root2 = sqrt(2.0);
	MaxHalfDimension = 0.4 * slack * sqrt(float(m * m + n * n));
	for(int i = 0;i <= m;i ++)
	{
		for(int j = 0;j <= n;j ++)
		{
			x[i][j][0] = slack * float(i - mcentre);
			x[i][j][1] = slack * float(j - ncentre);
			x[i][j][2] = SphereCentre[2] + SphereRadius;
			NodeType[i][j] = 0;
		}
	}
	glutInit(&argc,argv);
	MyGraphics(0.0,0.0,0.0);
	return 0;
}

static void Draw(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	Calculation();
	glPushMatrix();
	glLoadIdentity();
	
	glPointSize(10.0);
	if(ZoomButton == 1)glColor4f(1.0,0.0,0.0,0.5);else glColor4f(1.0,1.0,1.0,0.2);
	glBegin(GL_POINTS);
	PointPosition[0] = ZoomButtonX;
	PointPosition[1] = ZoomButtonY;
	glVertex2fv(PointPosition);
	glEnd();
	
	MyText="Zoom";
	glColor4f(1.0,1.0,1.0,0.2);
	glRasterPos2d(ZoomButtonX + 0.02,ZoomButtonY - 0.01);
	
	int StringLength=strlen(MyText);
	for(int MyChar=0;MyChar<StringLength;MyChar++)glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,MyText[MyChar]);
	
	glPopMatrix();
	glColor4f(1.0,1.0,1.0,0.25);
	glLineWidth(2.0);
	for(int j = 0;j <= n;j ++)
	{
		glBegin(GL_LINE_STRIP);
		for(int i = 0;i <= m;i ++)glVertex3fv(x[i][j]);
		glEnd();
	}
	for(int i = 0;i <= m;i ++)
	{
		glBegin(GL_LINE_STRIP);
		for(int j = 0;j <= n;j ++)
			glVertex3fv(x[i][j]);
		glEnd();
	}
	glutSwapBuffers();
}


void Calculation(void)
{
	for(int i = 0;i <= m;i ++)
	{
		for(int j = 0;j <= n;j ++)
		{
			Stiffness[i][j] = 0.0;
			force[i][j][0] = 0.0;force[i][j][1] = 0.0;force[i][j][2] =  - weightpernode;
		}
	}
	for(int i = 0;i <= m;i ++)
	{
		for(int j = 0;j <= n;j ++)
		{
			if(i < m)Axial(i,i + 1,j,j);
			if(j < n)Axial(i,i,j,j + 1);
			if(i < m - 1)Bending(i,i + 1,i + 2,j,j,j);
			if(j < n - 1)Bending(i,i,i,j,j + 1,j + 2);
		}
	}
	for(int j = 0;j <= n;j ++)
	{
		for(int i = 0;i <= m;i ++)
		{
			if(NodeType[i][j] == 0)
			{
				for(int xyz = 0;xyz <= 2;xyz ++)
				{
					velocity[i][j][xyz] = carryover * velocity[i][j][xyz]
					+ factor * force[i][j][xyz]/(Stiffness[i][j] + eighteta);
					x[i][j][xyz] = x[i][j][xyz] + velocity[i][j][xyz];
					Radius[xyz] = x[i][j][xyz] - SphereCentre[xyz];
				}
				if(x[i][j][2] < myfloor)
				{
					x[i][j][2] = myfloor;
					velocity[i][j][2] = 0.0;
				}
				RadSq = Radius[0] * Radius[0] + Radius[1] * Radius[1] + Radius[2] * Radius[2];
				if(RadSq<SphereRadiusSq)
				{
					dot = velocity[i][j][0] * Radius[0] + velocity[i][j][1] * Radius[1] + velocity[i][j][2] * Radius[2];
					Rad = sqrt(RadSq);
					for(int xyz = 0;xyz <= 2;xyz ++)
					{
						velocity[i][j][xyz] -= Radius[xyz] * dot/RadSq;
						x[i][j][xyz] += (SphereRadius - Rad) * Radius[xyz]/Rad;
					}
				}
			}
		}
	}
}

void Axial(int i,int inext,int j,int jnext)
{
	for(int xyz = 0;xyz <= 2;xyz ++)
		deltax[xyz] = x[inext][jnext][xyz] - x[i][j][xyz];
	float lengthSq = deltax[0] * deltax[0] + deltax[1] * deltax[1] + deltax[2] * deltax[2];
	float tensioncoefficient = EAOverTwoSlackCubed * (lengthSq - slackSq);
	float thisStiffness = EAOverTwoSlackCubed * (3.0 * lengthSq - 2.0 * slackSq);
	Stiffness[i][j] += thisStiffness;
	Stiffness[inext][jnext] += thisStiffness;
	for(int xyz = 0;xyz <= 2;xyz ++)
	{
		float thisforce = tensioncoefficient * deltax[xyz];
		force[i][j][xyz] += thisforce;
		force[inext][jnext][xyz] -= thisforce;
	}
}

void Bending(int i,int inext,int inextnext,int j,int jnext,int jnextnext)
{
	for(int xyz = 0;xyz <= 2;xyz ++)
	{
		deltaA[xyz] = x[inext][jnext][xyz] - x[i][j][xyz];
		deltaB[xyz] = x[inextnext][jnextnext][xyz] - x[inext][jnext][xyz];
		float thisforce = eta * (deltaA[xyz] - deltaB[xyz]);
		force[i][j][xyz] += thisforce;
		force[inext][jnext][xyz] -= 2.0 * thisforce;
		force[inextnext][jnextnext][xyz] += thisforce;
	}
}
